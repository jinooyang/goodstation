CREATE DATABASE  IF NOT EXISTS `goodstation` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `goodstation`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: goodstation
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'역이어때 사용방법','여행을 계획하고 있다면, 당신이 필요로 하는 기차 운행 정보를 손쉽게 찾을 수 있습니다. 원하는 출발지와 도착지, 특정 날짜 및 시간을 선택하면, 여러 기차 회사의 다양한 운행 정보 중에서 가장 편리하고 시간에 맞는 옵션을 찾을 수 있습니다.\n\n당신의 여행을 더욱 풍요롭게 만들기 위해, 역 주변의 다양한 관광지를 편리하게 선택할 수 있는 기회가 여기 있습니다. 클릭 한 번으로 현지의 아름다운 명소와 문화적 경험을 탐험하고, 당신만의 특별한 여행을 계획하세요.\n\n여행을 계획하고 있다면, 당신이 필요로 하는 기차 운행 정보를 손쉽게 찾을 수 있습니다. 원하는 출발지와 도착지, 특정 날짜 및 시간을 선택하면, 여러 기차 회사의 다양한 운행 정보 중에서 가장 편리하고 시간에 맞는 옵션을 찾을 수 있습니다.','2023-11-23 13:01:54','관리자'),(2,'관광지 업데이트','부산역 관광지가 업데이트 되었습니다. 2023.11.23','2023-11-23 13:04:02','관리자'),(3,'역이어때 이벤트','댓글 추첨 이벤트 곧 진행할 예정입니다','2023-11-23 13:11:34','관리자'),(4,'즐거운 연휴 보내세요!','운영자 일동','2023-11-23 13:12:49','관리자');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-24  9:27:30
